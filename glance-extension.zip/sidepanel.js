const $ = (id) => document.getElementById(id);

const DEFAULTS = {
  apiKey: '',
  model: 'gemini-2.5-flash-lite',
  detail: 1024,
  maxTokens: 600,
  humanize: true,
  last: null
};

const DEFAULT_QUESTION = "What's on my screen? If it shows a question, error, or task, answer or solve it.";

// Style rules go in the system instruction so the model writes plainly in the first place.
const SYSTEM = [
  'You read screenshots and answer briefly.',
  'Answer the question directly, with specifics from the screen: names, numbers, exact error text.',
  'Plain text only. No markdown, bold, headings, emoji, or em dashes.',
  'Use contractions. Mix short and long sentences. No greeting, no sign-off, no offer of more help.',
  'Avoid filler words like delve, leverage, seamless, robust, crucial, landscape, tapestry, testament.',
  'If something is unreadable, say so instead of guessing.'
].join(' ');

let settings = { ...DEFAULTS };
let reply = { raw: '', clean: '' };
let view = 'clean';
let controller = null;

// ---------- settings ----------
async function loadSettings() {
  settings = await chrome.storage.local.get(DEFAULTS);
  $('apiKey').value = settings.apiKey;
  $('model').value = settings.model;
  $('detail').value = String(settings.detail);
  $('maxTokens').value = String(settings.maxTokens);
  $('humanize').checked = settings.humanize;
  if (settings.last && settings.last.raw) {
    showReply(settings.last.raw, settings.last.usage);
  }
  if (!settings.apiKey) openSettings();
}

function saveSettings() {
  settings.apiKey = $('apiKey').value.trim();
  settings.model = $('model').value.trim() || DEFAULTS.model;
  settings.detail = Number($('detail').value);
  settings.maxTokens = Number($('maxTokens').value);
  settings.humanize = $('humanize').checked;
  chrome.storage.local.set({
    apiKey: settings.apiKey,
    model: settings.model,
    detail: settings.detail,
    maxTokens: settings.maxTokens,
    humanize: settings.humanize
  });
  if (reply.raw) renderReply();
}

function openSettings() {
  $('settings').hidden = false;
  $('settingsBtn').setAttribute('aria-expanded', 'true');
}

$('settingsBtn').addEventListener('click', () => {
  const open = $('settings').hidden;
  $('settings').hidden = !open;
  $('settingsBtn').setAttribute('aria-expanded', String(open));
});
['apiKey', 'model', 'detail', 'maxTokens', 'humanize'].forEach((id) => $(id).addEventListener('change', saveSettings));

// ---------- capture ----------
async function captureTab() {
  const win = await chrome.windows.getCurrent();
  return chrome.tabs.captureVisibleTab(win.id, { format: 'jpeg', quality: 90 });
}

async function captureScreen() {
  const stream = await navigator.mediaDevices.getDisplayMedia({ video: true, audio: false });
  try {
    const video = document.createElement('video');
    video.muted = true;
    video.srcObject = stream;
    await video.play();
    await new Promise((r) => setTimeout(r, 300));
    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    canvas.getContext('2d').drawImage(video, 0, 0);
    return canvas.toDataURL('image/jpeg', 0.9);
  } finally {
    stream.getTracks().forEach((t) => t.stop());
  }
}

// Smaller images use fewer tokens. 768px on the long side is about one 258-token tile.
function downscale(dataUrl) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      const scale = Math.min(1, settings.detail / Math.max(img.width, img.height));
      const canvas = document.createElement('canvas');
      canvas.width = Math.round(img.width * scale);
      canvas.height = Math.round(img.height * scale);
      canvas.getContext('2d').drawImage(img, 0, 0, canvas.width, canvas.height);
      resolve(canvas.toDataURL('image/jpeg', 0.72));
    };
    img.onerror = () => reject(new Error('Could not read the capture.'));
    img.src = dataUrl;
  });
}

// ---------- Gemini ----------
async function askGemini(base64, question) {
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(settings.model)}:generateContent`;
  const res = await fetch(url, {
    method: 'POST',
    signal: controller.signal,
    headers: { 'Content-Type': 'application/json', 'x-goog-api-key': settings.apiKey },
    body: JSON.stringify({
      systemInstruction: { parts: [{ text: SYSTEM }] },
      contents: [{
        role: 'user',
        parts: [
          { inline_data: { mime_type: 'image/jpeg', data: base64 } },
          { text: question || DEFAULT_QUESTION }
        ]
      }],
      generationConfig: { maxOutputTokens: settings.maxTokens, temperature: 0.5 }
    })
  });

  if (!res.ok) {
    let detail = '';
    try { detail = (await res.json()).error?.message || ''; } catch (_) {}
    const err = new Error(detail || `Request failed (${res.status})`);
    err.status = res.status;
    throw err;
  }

  const json = await res.json();
  const text = (json.candidates?.[0]?.content?.parts || []).map((p) => p.text || '').join('').trim();
  if (!text) {
    const why = json.promptFeedback?.blockReason || json.candidates?.[0]?.finishReason || 'empty reply';
    throw new Error(`Gemini returned no text (${why}).`);
  }
  const u = json.usageMetadata || {};
  return { text, usage: { input: u.promptTokenCount, output: u.candidatesTokenCount } };
}

function friendlyError(e) {
  if (e.name === 'AbortError') return 'Stopped.';
  const msg = e.message || String(e);
  if (e.status === 400 && /api key/i.test(msg)) return 'Gemini rejected the API key. Check it in settings.';
  if (e.status === 403) return 'The key was accepted but not allowed to use this model.';
  if (e.status === 404) return 'Model not found. Check the model name in settings.';
  if (e.status === 429) return 'Rate limit reached. Wait a minute, or check your quota in AI Studio.';
  if (/cannot be captured|cannot access|chrome:\/\/|extensions gallery/i.test(msg)) {
    return "Chrome doesn't allow capturing this page. Switch to a regular website and try again.";
  }
  if (e.name === 'NotAllowedError') return 'Screen selection was cancelled.';
  return msg;
}

// ---------- UI ----------
function setStatus(text, isError) {
  $('status').textContent = text || '';
  $('status').classList.toggle('error', !!isError);
}

function setBusy(busy) {
  $('askTab').disabled = busy;
  $('askScreen').disabled = busy;
  $('stop').hidden = !busy;
}

function showReply(raw, usage) {
  reply.raw = raw;
  reply.clean = window.humanize(raw);
  $('reply').hidden = false;
  renderReply();
  $('usage').textContent = usage && usage.input != null
    ? `${usage.input} tokens in, ${usage.output ?? 0} out`
    : '';
}

function renderReply() {
  const useClean = settings.humanize && view === 'clean';
  $('replyText').textContent = useClean ? reply.clean : reply.raw;
  $('showClean').setAttribute('aria-pressed', String(view === 'clean'));
  $('showRaw').setAttribute('aria-pressed', String(view === 'raw'));
  $('showClean').disabled = !settings.humanize;
}

async function run(source) {
  if (!settings.apiKey) {
    openSettings();
    setStatus('Add your Gemini API key first.', true);
    return;
  }
  setBusy(true);
  controller = new AbortController();
  try {
    setStatus(source === 'tab' ? 'Capturing tab...' : 'Choose a screen or window to share...');
    const full = source === 'tab' ? await captureTab() : await captureScreen();
    const small = await downscale(full);
    $('shotImg').src = small;
    $('shot').hidden = false;

    setStatus('Asking Gemini...');
    const { text, usage } = await askGemini(small.split(',')[1], $('prompt').value.trim());
    showReply(text, usage);
    chrome.storage.local.set({ last: { raw: text, usage } });
    setStatus('');
  } catch (e) {
    setStatus(friendlyError(e), e.name !== 'AbortError');
  } finally {
    controller = null;
    setBusy(false);
  }
}

$('askTab').addEventListener('click', () => run('tab'));
$('askScreen').addEventListener('click', () => run('screen'));
$('stop').addEventListener('click', () => controller && controller.abort());
$('prompt').addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) { e.preventDefault(); run('tab'); }
});

$('showClean').addEventListener('click', () => { view = 'clean'; renderReply(); });
$('showRaw').addEventListener('click', () => { view = 'raw'; renderReply(); });

$('copy').addEventListener('click', async () => {
  const text = $('replyText').textContent;
  try {
    await navigator.clipboard.writeText(text);
  } catch (_) {
    const ta = document.createElement('textarea');
    ta.value = text;
    document.body.appendChild(ta);
    ta.select();
    document.execCommand('copy');
    ta.remove();
  }
  $('copy').textContent = 'Copied';
  setTimeout(() => ($('copy').textContent = 'Copy'), 1400);
});

loadSettings();
