// Rule-based cleanup for text that reads as machine-written.
// Runs locally, so it costs no extra API usage.
(function () {
  const cap = (s) => (s ? s[0].toUpperCase() + s.slice(1) : s);
  const keepCase = (m, r) => (/^[A-Z]/.test(m) ? cap(r) : r);

  // Phrases and words that show up far more in model output than in people's writing.
  const SWAPS = {
    'in the ever-evolving world of': 'in',
    'navigate the complexities of': 'deal with',
    'navigating the complexities of': 'dealing with',
    'navigate the landscape of': 'work through',
    'navigating the landscape of': 'working through',
    'unlock the full potential of': 'get more out of',
    'unlock the potential of': 'get more out of',
    'unlocking the potential of': 'getting more out of',
    'embark on a journey': 'start',
    'embarking on a journey': 'starting',
    'serves as a testament to': 'shows',
    'is a testament to': 'shows',
    'a testament to': 'proof of',
    'plays a crucial role in': 'matters for',
    'play a crucial role in': 'matter for',
    'plays a vital role in': 'matters for',
    'play a vital role in': 'matter for',
    'plays a key role in': 'matters for',
    'plays a pivotal role in': 'matters for',
    'delve into': 'look into', 'delves into': 'looks into',
    'delved into': 'looked into', 'delving into': 'looking into',
    'robust solution': 'solid option', 'robust framework': 'solid framework',
    'holistic approach': 'broad approach',
    'seamlessly integrate': 'fit in', 'seamlessly integrates': 'fits in',
    'a plethora of': 'plenty of', 'a myriad of': 'many',
    'rich tapestry of': 'mix of', 'realm of': 'area of',
    'cutting-edge': 'new', 'game-changing': 'major', 'game-changer': 'big shift',
    'revolutionary': 'new', 'seamlessly': 'smoothly', 'seamless': 'smooth',
    'crucial': 'important', 'pivotal': 'key', 'robust': 'solid',
    'vibrant': 'lively', 'intricate': 'detailed', 'multifaceted': 'complex',
    'meticulously': 'carefully', 'meticulous': 'careful',
    'plethora': 'plenty', 'myriad': 'many', 'tapestry': 'mix',
    'leverage': 'use', 'leverages': 'uses', 'leveraged': 'used', 'leveraging': 'using',
    'utilize': 'use', 'utilizes': 'uses', 'utilized': 'used', 'utilizing': 'using',
    'optimize': 'improve', 'optimizes': 'improves', 'optimized': 'improved', 'optimizing': 'improving',
    'streamline': 'simplify', 'streamlines': 'simplifies', 'streamlined': 'simplified', 'streamlining': 'simplifying',
    'empower': 'help', 'empowers': 'helps', 'empowered': 'helped', 'empowering': 'helping',
    'foster': 'build', 'fosters': 'builds', 'fostered': 'built', 'fostering': 'building',
    'cultivate': 'build', 'cultivates': 'builds', 'cultivated': 'built', 'cultivating': 'building',
    'showcase': 'show', 'showcases': 'shows', 'showcased': 'showed', 'showcasing': 'showing',
    'underscore': 'show', 'underscores': 'shows', 'underscored': 'showed', 'underscoring': 'showing',
    'elevate': 'raise', 'elevates': 'raises', 'harness': 'use', 'harnesses': 'uses', 'harnessing': 'using'
  };
  const swapRe = new RegExp(
    '\\b(' + Object.keys(SWAPS).sort((a, b) => b.length - a.length).map((k) => k.replace(/[-]/g, '\\-')).join('|') + ')\\b',
    'gi'
  );

  const START = '(^|[.!?]\\s+|\\n)';
  const M = '\u0001'; // marks a sentence start where we removed a lead-in
  const lead = (body) => new RegExp(START + '(?:' + body + ')\\s*', 'gi');

  const LEADS = [
    "(?:it is|it's) (?:important|worth|crucial|essential) (?:to note|noting|to remember|to understand|to mention) that,?",
    "in today's (?:fast-paced world|digital age|digital world|modern world|world),?",
    'at its core,?', 'in essence,?', 'ultimately,?', 'overall,?',
    'in conclusion,?', 'in summary,?', 'to summarize,?', 'to sum up,?',
    'moreover,?', 'furthermore,?', 'additionally,?', 'in addition,?'
  ].map(lead);

  const MID_FLUFF = /\b(?:it is|it's) (?:important|worth|crucial|essential) (?:to note|noting|to remember|to understand|to mention) that,?\s*/gi;

  function humanize(input) {
    if (!input) return '';
    let t = String(input);

    // Protect code and quoted text so error messages and snippets stay exact.
    const store = [];
    t = t.replace(/```[\s\S]*?```|`[^`\n]+`|"[^"\n]{1,200}"|\u201c[^\u201d\n]{1,200}\u201d/g, (m) => {
      store.push(m);
      return '\u0002' + (store.length - 1) + '\u0002';
    });

    t = t.replace(/[\u2018\u2019]/g, "'").replace(/[\u201c\u201d]/g, '"');

    // Greeting, sign-off, and framing lines.
    t = t.replace(/^\s*(?:sure|certainly|absolutely|of course|great question|okay|ok)[!,.]\s*/i, '');
    t = t.replace(/^\s*(?:here'?s|here is) (?:a|an|the) [^\n:]{0,50}:\s*\n/i, '');
    t = t.replace(/\s*(?:I hope (?:this|that) helps|let me know if [^.\n]*|feel free to [^.\n]*|if you (?:have|need) any (?:other|more|further) [^.\n]*)[.!]?\s*$/i, '');

    // Lead-ins that add nothing.
    LEADS.forEach((re) => { t = t.replace(re, '$1' + M); });
    t = t.replace(MID_FLUFF, '');

    // Stock phrases and words.
    t = t.replace(swapRe, (m) => keepCase(m, SWAPS[m.toLowerCase()]));

    // Formatting that reads as a template.
    t = t.replace(/\*\*(.+?)\*\*/g, '$1').replace(/__(.+?)__/g, '$1');
    t = t.replace(/(?<![\w*])\*(?![\s*])([^*\n]+?)\*(?![\w*])/g, '$1');
    t = t.replace(/^\s{0,3}#{1,6}\s+/gm, '');
    t = t.replace(/^\s*[*\u2022]\s+/gm, '- ');
    t = t.replace(/[\u2014\u2015]/g, ' - ').replace(/\s+-\s+/g, (m, off, s) => (m.includes('\n') ? m : ', '));
    t = t.replace(/\s+\u2013\s+/g, ', ');
    t = t.replace(/\s*\u2192\s*/g, ' to ');
    t = t.replace(/[\p{Extended_Pictographic}\uFE0F\u200D]/gu, '');

    // Contractions: stiff "do not" reads as formal or machine-written.
    t = t.replace(/\bcannot\b/gi, (m) => keepCase(m, "can't"));
    t = t.replace(/\bwill not\b/gi, (m) => keepCase(m, "won't"));
    t = t.replace(/\b(do|does|did|is|are|was|were|has|have|had|would|should|could) not\b/gi, "$1n't");
    t = t.replace(/\b(it|that|there|here|what|who) is\b(?=\s+[a-z])/gi, "$1's");
    t = t.replace(/\b(you|we|they) are\b(?=\s+[a-z])/gi, "$1're");
    t = t.replace(/\bI am\b/g, "I'm");
    t = t.replace(/\b(I|you|we|they|he|she|it) will\b/g, "$1'll");

    // Tidy spacing, then fix capitalization where a lead-in was removed.
    t = t.replace(/,\s*,/g, ',').replace(/\s+([,.;:!?])/g, '$1').replace(/,\s*([.!?])/g, '$1');
    t = t.replace(/[ \t]{2,}/g, ' ').replace(/[ \t]+$/gm, '').replace(/\n{3,}/g, '\n\n');
    t = t.replace(new RegExp(M + '\\s*([a-z])', 'g'), (m, c) => c.toUpperCase()).replace(new RegExp(M, 'g'), '');
    t = t.trim();

    t = t.replace(/\u0002(\d+)\u0002/g, (m, i) => store[+i]);
    return t;
  }

  window.humanize = humanize;
})();
